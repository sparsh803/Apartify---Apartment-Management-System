# Apartify-Apartment-Management-System

<p>Apartify is an Apartment Management System designed to be used by residential property owners to keep track of tenants occupying their properties and collecting rents monthly.</p>

<h4>Key Features</h4>
<ol type="a">
  <li>Allows owner to add new property details</li>
  <li>Add new Tenant details</li>
  <li>Display dues of every tenant</li>
  <li>Display payment history of every tenant</li>
  <li>Create monthly payment reports and download them in PDF form</li>
</ol>
